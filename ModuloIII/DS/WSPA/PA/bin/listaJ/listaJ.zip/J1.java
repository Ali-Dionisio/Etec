package listaJ;


public class J1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 1;
		
		while(n <= 100){
			System.out.println(n);
			n++;
		}
	}

}
