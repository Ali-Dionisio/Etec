package colegioRitaLee;

public class NotasFaltas extends Boletim{
	private boolean retornavel;

	public String mostrarBebida(){
		return 	
				"Nome: " + this.getNome() + 
				"\nPreco: " + this.getPreco() +
				"\nRetornavel: " + retornavel;
	}
	
	public NotasFaltas() {
		//
	}

	public NotasFaltas(String vNome, double vPreco, boolean vRetornavel){ //Vinho = construtor
		this.setNome(vNome);
		this.setPreco(vPreco);
		this.retornavel = vRetornavel;
		
		
	}
	
	public boolean verificarPreco(double preco) {
		if(preco<5) {
			return true;
		}else {
			return false;
		
		}
	}
	
	public boolean getRetornavel() {
		return retornavel;
	}

	public void setRetornavel(boolean retornavel) {
		this.retornavel = retornavel;
	}
	
	
}
