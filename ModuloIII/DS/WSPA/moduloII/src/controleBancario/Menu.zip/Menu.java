package controleBancario;

public class Menu {

	private int opcao;
	private String mensagemMenu;
	public int getOpcao() {
		return opcao;
	}
	public void setOpcao(int opcao) {
		this.opcao = opcao;
	}
	public String getMensagemMenu() {
		return mensagemMenu;
	}
	public void setMensagemMenu(String mensagemMenu) {
		this.mensagemMenu = mensagemMenu;
	}
	public void executar() {
	}
	protected void executarMenu() {
	}
	protected void avaliarOpcaoEscolhida() {
		
	}
}
