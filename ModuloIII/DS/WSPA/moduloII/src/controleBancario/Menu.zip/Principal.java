package controleBancario;

public class Principal {

	public static void main(String[] args) {
		
		MenuConta menu=new MenuConta();
		
		menu.executarMenu();
		
		
	}

}
